/* Chiếc Nón Kỳ Diệu — game engine */
(function () {
  'use strict';

  /* ---------------- bảng chữ cái tiếng Việt ---------------- */
  const GROUPS = {
    'A': 'AÁÀẢÃẠ', 'Ă': 'ĂẮẰẲẴẶ', 'Â': 'ÂẤẦẨẪẬ',
    'E': 'EÉÈẺẼẸ', 'Ê': 'ÊẾỀỂỄỆ',
    'I': 'IÍÌỈĨỊ',
    'O': 'OÓÒỎÕỌ', 'Ô': 'ÔỐỒỔỖỘ', 'Ơ': 'ƠỚỜỞỠỢ',
    'U': 'UÚÙỦŨỤ', 'Ư': 'ƯỨỪỬỮỰ',
    'Y': 'YÝỲỶỸỴ',
    'Đ': 'Đ'
  };
  const ALPHABET = ['A','Ă','Â','B','C','D','Đ','E','Ê','F','G','H','I','J','K','L','M','N','O','Ô','Ơ','P','Q','R','S','T','U','Ư','V','W','X','Y','Z'];
  const BASE = {};
  for (const k in GROUPS) for (const ch of GROUPS[k]) BASE[ch] = k;
  for (const L of ALPHABET) if (!BASE[L]) BASE[L] = L;
  const baseOf = ch => BASE[ch] || null;

  const FLAT = { 'Ă':'A','Â':'A','Ê':'E','Ô':'O','Ơ':'O','Ư':'U','Đ':'D' };
  function loose(s) {
    let out = '';
    for (const ch of (s || '').toUpperCase()) {
      const b = baseOf(ch);
      if (b) out += (FLAT[b] || b);
      else if (/[A-Z0-9]/.test(ch)) out += ch;
    }
    return out;
  }

  /* ---------------- các ô trên vòng quay ---------------- */
  const SEGS = [
    { t:'pts', v:200 },
    { t:'lose',   l:'MẤT LƯỢT' },
    { t:'pts', v:400 },
    { t:'double', l:'GẤP ĐÔI' },
    { t:'pts', v:300 },
    { t:'lucky',  l:'MAY MẮN' },
    { t:'pts', v:500 },
    { t:'half',   l:'CHIA ĐÔI' },
    { t:'pts', v:200 },
    { t:'life',   l:'THÊM MẠNG' },
    { t:'pts', v:600 },
    { t:'zero',   l:'MẤT ĐIỂM' },
    { t:'pts', v:300 },
    { t:'swap',   l:'ĐỔI CÂU' },
    { t:'pts', v:400 },
    { t:'bet',    l:'CƯỢC ĐÔI' },
    { t:'pts', v:800 },
    { t:'danger', l:'CÚN GẶP NGUY' },
    { t:'pts', v:300 },
    { t:'again',  l:'QUAY LẠI' },
    { t:'pts', v:500 },
    { t:'life',   l:'CỨU TRỢ' },
    { t:'pts', v:1000 },
    { t:'gift',   l:'CHÚC MỪNG' }
  ];
  const COLORS = {
    lose:   ['#3D1226', '#FFE2B8'],
    double: ['#2FBE9F', '#04271F'],
    half:   ['#2C7E93', '#EAFBFF'],
    life:   ['#5FB94F', '#092C05'],
    lucky:  ['#9B6BFF', '#1B0A3A'],
    swap:   ['#4E9BF0', '#04203F'],
    bet:    ['#E06AA6', '#320A20'],
    danger: ['#D62828', '#FFE6E1'],
    again:  ['#F0E4C6', '#4A2A06'],
    zero:   ['#2A2A33', '#D8D8E4'],
    gift:   ['#F5822B', '#311000']
  };
  const PTS_A = ['#8E0E24', '#FFE2B8'];
  const PTS_B = ['#F2B33C', '#42130A'];

  /* ---------------- âm thanh ---------------- */
  const A = { ctx:null, master:null, musicGain:null, sfxGain:null, on:false, timer:null, step:0, next:0, noise:null };
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

  function audioInit() {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return true; }
    try {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return false;
      A.ctx = new C();
      A.master = A.ctx.createGain(); A.master.gain.value = 0.85; A.master.connect(A.ctx.destination);
      A.musicGain = A.ctx.createGain(); A.musicGain.gain.value = 0; A.musicGain.connect(A.master);
      A.sfxGain = A.ctx.createGain(); A.sfxGain.gain.value = 0.85; A.sfxGain.connect(A.master);
      const len = A.ctx.sampleRate * 0.5, buf = A.ctx.createBuffer(1, len, A.ctx.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      A.noise = buf;
      return true;
    } catch (e) { return false; }
  }
  function tone(freq, t0, dur, type, gain, dest) {
    if (!A.ctx) return;
    const o = A.ctx.createOscillator(), g = A.ctx.createGain();
    o.type = type || 'triangle'; o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), t0 + 0.014);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(dest || A.sfxGain);
    o.start(t0); o.stop(t0 + dur + 0.06);
  }
  function noiseHit(t0, dur, gain, hp, dest) {
    if (!A.ctx || !A.noise) return;
    const s = A.ctx.createBufferSource(); s.buffer = A.noise;
    const f = A.ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp || 2000;
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f); f.connect(g); g.connect(dest || A.sfxGain);
    s.start(t0); s.stop(t0 + dur + 0.02);
  }
  const now = () => (A.ctx ? A.ctx.currentTime : 0);
  const sfx = {
    tick() { if (A.ctx) { tone(1500, now(), 0.035, 'square', 0.09); } },
    click() { if (A.ctx) tone(760, now(), 0.07, 'triangle', 0.12); },
    good() { if (!A.ctx) return; const t = now(); [659, 831, 988].forEach((f, i) => tone(f, t + i * 0.07, 0.22, 'triangle', 0.2)); },
    big() { if (!A.ctx) return; const t = now(); [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, t + i * 0.09, 0.42, 'sawtooth', 0.14)); },
    bad() {
      if (!A.ctx) return; const t = now();
      const o = A.ctx.createOscillator(), g = A.ctx.createGain();
      o.type = 'sawtooth'; o.frequency.setValueAtTime(320, t); o.frequency.exponentialRampToValueAtTime(90, t + 0.45);
      g.gain.setValueAtTime(0.18, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
      o.connect(g); g.connect(A.sfxGain); o.start(t); o.stop(t + 0.55);
    },
    fail() { if (!A.ctx) return; const t = now(); [440, 392, 330, 262].forEach((f, i) => tone(f, t + i * 0.16, 0.4, 'triangle', 0.18)); },
    whoosh() { noiseHit(now(), 0.5, 0.1, 500); },
    life() { if (!A.ctx) return; const t = now(); [523, 784, 1047].forEach((f, i) => tone(f, t + i * 0.06, 0.25, 'sine', 0.2)); }
  };

  const CHORDS = [[60,64,67],[57,60,64],[53,57,60],[55,59,62],[60,64,67],[57,60,64],[53,57,60],[55,59,62]];
  const MEL = [
    [72,74,76, 0,76,74,72, 0],
    [72,71,69, 0,69,71,72, 0],
    [69,71,72, 0,74, 0,72, 0],
    [71, 0,74, 0,71,69,67, 0],
    [76, 0,79, 0,76,74,72, 0],
    [74, 0,76, 0,74,72,71, 0],
    [72,74,76, 0,77, 0,76, 0],
    [74, 0,71, 0,67, 0, 0, 0]
  ];
  const BPM = 116, STEP = (60 / BPM) / 4;

  function scheduleStep(s, t) {
    const bar = Math.floor(s / 16) % 8, p = s % 16, ch = CHORDS[bar];
    if (p % 2 === 0) {
      const m = MEL[bar][p / 2];
      if (m) tone(mtof(m), t, 0.26, 'triangle', 0.09, A.musicGain);
    }
    if (p === 0 || p === 6 || p === 8) tone(mtof(ch[0] - 24), t, 0.3, 'sine', 0.17, A.musicGain);
    if (p % 4 === 2) tone(mtof(ch[(((p - 2) / 4) % 3)] + 12), t, 0.14, 'square', 0.028, A.musicGain);
    if (p % 2 === 0) noiseHit(t, 0.03, 0.02, 6000, A.musicGain);
    if (p === 4 || p === 12) noiseHit(t, 0.12, 0.05, 1400, A.musicGain);
  }
  function musicStart() {
    if (!A.ctx || A.timer) return;
    A.next = A.ctx.currentTime + 0.1;
    A.timer = setInterval(() => {
      if (!A.ctx) return;
      while (A.next < A.ctx.currentTime + 0.18) { scheduleStep(A.step, A.next); A.step++; A.next += STEP; }
    }, 28);
  }
  function musicStop() { if (A.timer) { clearInterval(A.timer); A.timer = null; } }
  function setMusic(on) {
    A.on = on;
    const btn = $('btnMusic');
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    btn.textContent = on ? '♪ Nhạc nền: bật' : '♪ Nhạc nền: tắt';
    if (!audioInit()) return;
    const g = A.musicGain.gain, t = A.ctx.currentTime;
    g.cancelScheduledValues(t); g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(on ? 0.2 : 0.0001, t + 0.6);
    if (on) musicStart(); else setTimeout(musicStop, 700);
  }

  /* ---------------- tiện ích DOM ---------------- */
  const $ = id => document.getElementById(id);
  const el = (tag, cls, txt) => { const n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = txt; return n; };
  const fmt = n => n.toLocaleString('vi-VN');

  /* ---------------- trạng thái ---------------- */
  const S = {
    started: false, mode: 'solo', players: [], cur: 0,
    round: 1, maxRounds: Infinity,
    answer: '', cat: '', question: '',
    revealed: [], used: [],
    pending: null, mult: 1, betting: false,
    spinning: false, canSpin: true,
    pool: [], solvedCount: 0, angle: 0
  };
  const MAX_LIVES = 8, START_LIVES = 5;

  /* ---------------- ngân hàng câu hỏi ---------------- */
  function freshPool() {
    const b = (window.QBANK || []).slice();
    for (let i = b.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [b[i], b[j]] = [b[j], b[i]]; }
    return b;
  }
  function nextPuzzle() {
    if (!S.pool.length) S.pool = freshPool();
    const q = S.pool.pop() || ['CHIẾC NÓN KỲ DIỆU', 'Trò chơi', 'Trò chơi bạn đang chơi tên là gì?'];
    S.answer = q[0]; S.cat = q[1]; S.question = q[2];
    S.revealed = []; S.used = []; S.pending = null; S.mult = 1; S.betting = false;
  }

  const letterSet = () => {
    const s = new Set();
    for (const ch of S.answer) { const b = baseOf(ch); if (b) s.add(b); }
    return s;
  };
  const hiddenCount = () => {
    let n = 0;
    for (const ch of S.answer) { const b = baseOf(ch); if (b && S.revealed.indexOf(b) < 0) n++; }
    return n;
  };
  const isSolved = () => hiddenCount() === 0;

  /* ---------------- vòng quay ---------------- */
  const cv = $('wheel'), ctx = cv.getContext('2d');
  const R = 400, CX = 420, CY = 420, STEP_ANG = (Math.PI * 2) / SEGS.length;

  function drawWheel(rot) {
    S.angle = rot;
    ctx.clearRect(0, 0, 840, 840);
    ctx.save(); ctx.translate(CX, CY);
    ctx.beginPath(); ctx.arc(0, 0, R + 14, 0, Math.PI * 2);
    ctx.fillStyle = '#4A2A06'; ctx.fill();
    ctx.save(); ctx.rotate(rot);
    let ptsIdx = 0;
    SEGS.forEach((seg, i) => {
      const a0 = i * STEP_ANG, a1 = a0 + STEP_ANG;
      let pair;
      if (seg.t === 'pts') { pair = (ptsIdx % 2 === 0) ? PTS_A : PTS_B; ptsIdx++; }
      else pair = COLORS[seg.t] || PTS_A;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, R, a0, a1); ctx.closePath();
      ctx.fillStyle = pair[0]; ctx.fill();
      ctx.strokeStyle = 'rgba(255,225,170,.55)'; ctx.lineWidth = 2.5; ctx.stroke();

      const label = seg.t === 'pts' ? String(seg.v) : seg.l;
      ctx.save(); ctx.rotate(a0 + STEP_ANG / 2);
      ctx.fillStyle = pair[1]; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      let size = seg.t === 'pts' ? 60 : 36;
      ctx.font = size + 'px Anton, Impact, sans-serif';
      while (ctx.measureText(label).width > R - 130 && size > 16) {
        size -= 2; ctx.font = size + 'px Anton, Impact, sans-serif';
      }
      ctx.fillText(label, R - 26, 0);
      ctx.restore();
    });
    ctx.restore();
    // vành ngoài + bóng đèn
    ctx.beginPath(); ctx.arc(0, 0, R + 7, 0, Math.PI * 2);
    ctx.lineWidth = 14; ctx.strokeStyle = '#8E5711'; ctx.stroke();
    for (let i = 0; i < SEGS.length; i++) {
      const a = rot + i * STEP_ANG;
      const x = Math.cos(a) * (R + 7), y = Math.sin(a) * (R + 7);
      ctx.beginPath(); ctx.arc(x, y, 6.5, 0, Math.PI * 2);
      ctx.fillStyle = (Math.floor(Date.now() / 260) + i) % 2 ? '#FFE9A8' : '#C88A2A';
      ctx.fill();
    }
    ctx.restore();
  }

  let blink = null;
  function startBlink() { if (!blink) blink = setInterval(() => { if (!S.spinning) drawWheel(S.angle); }, 260); }

  function spin() {
    if (S.spinning || !S.canSpin || !S.started) return;
    audioInit(); sfx.whoosh();
    S.spinning = true; S.canSpin = false;
    updateControls();
    setMsg('Nón đang quay...', '');
    $('hubText').innerHTML = '...';

    const idx = Math.random() * SEGS.length | 0;
    const center = (idx + 0.5) * STEP_ANG;
    const jitter = (Math.random() - 0.5) * STEP_ANG * 0.6;
    const target = -Math.PI / 2 - center - jitter;
    const turns = 6 + Math.floor(Math.random() * 3);
    let from = S.angle % (Math.PI * 2);
    let to = target;
    while (to < from + turns * Math.PI * 2) to += Math.PI * 2;

    const dur = 4300, t0 = performance.now();
    let lastSeg = -1;
    (function frame(t) {
      const p = Math.min(1, (t - t0) / dur);
      const e = 1 - Math.pow(1 - p, 4);
      const ang = from + (to - from) * e;
      drawWheel(ang);
      const segNow = Math.floor(((-Math.PI / 2 - ang) / STEP_ANG) % SEGS.length);
      if (segNow !== lastSeg) { lastSeg = segNow; if (p < 0.98) sfx.tick(); }
      if (p < 1) requestAnimationFrame(frame);
      else { S.spinning = false; land(SEGS[idx]); }
    })(t0);
  }

  /* ---------------- kết quả ô quay ---------------- */
  function land(seg) {
    const p = S.players[S.cur];
    const nm = p.name;
    if (seg.t === 'pts') {
      S.pending = seg.v;
      $('hubText').innerHTML = fmt(seg.v);
      setMsg('Quay trúng <b>' + fmt(seg.v) + ' điểm</b> mỗi chữ cái. ' + nm + ' hãy chọn một chữ cái!', 'gold');
      sfx.click(); S.canSpin = false; updateControls(); return;
    }
    $('hubText').innerHTML = seg.l.replace(' ', '<br>');
    switch (seg.t) {
      case 'lose':
        sfx.bad(); setMsg(multi()
          ? '<b>MẤT LƯỢT!</b> ' + nm + ' phải nhường nón cho người kế tiếp.'
          : '<b>MẤT LƯỢT!</b> Lượt quay này không được điểm nào. Quay lại nào!', 'bad');
        return void setTimeout(passTurn, 1100);
      case 'double':
        p.score *= 2; sfx.big();
        setMsg('<b>GẤP ĐÔI!</b> Điểm của ' + nm + ' nhân đôi thành ' + fmt(p.score) + '. Quay tiếp nào!', 'good');
        break;
      case 'half':
        p.score = Math.floor(p.score / 2); sfx.bad();
        setMsg('<b>CHIA ĐÔI.</b> Điểm của ' + nm + ' còn ' + fmt(p.score) + '. Vẫn được quay tiếp.', 'bad');
        break;
      case 'life':
        p.lives = Math.min(MAX_LIVES, p.lives + 1); sfx.life();
        setMsg('<b>THÊM MẠNG!</b> Cún của ' + nm + ' được tiếp sức, hiện còn ' + p.lives + ' mạng.', 'good');
        break;
      case 'lucky': {
        const hidden = [...letterSet()].filter(L => S.revealed.indexOf(L) < 0);
        if (hidden.length) {
          const L = hidden[Math.random() * hidden.length | 0];
          S.revealed.push(L); if (S.used.indexOf(L) < 0) S.used.push(L);
          sfx.good();
          setMsg('<b>MAY MẮN!</b> Chữ <b>' + L + '</b> được mở miễn phí cho ' + nm + '.', 'good');
          renderBoard(L);
          if (isSolved()) return void setTimeout(() => finishRound(p, 0, 'mở hết chữ cái'), 900);
        } else setMsg('<b>MAY MẮN!</b> Nhưng ô chữ đã lộ hết rồi. Quay tiếp nhé.', 'good');
        break;
      }
      case 'swap': {
        const old = S.answer;
        nextPuzzle(); renderBoard(); sfx.click();
        setMsg('<b>ĐỔI CÂU!</b> Ô chữ cũ là <b>' + esc(old) + '</b>. ' + nm + ' nhận một câu hỏi mới và được quay tiếp.', 'good');
        break;
      }
      case 'again':
        sfx.click(); setMsg('<b>QUAY LẠI!</b> ' + nm + ' được quay thêm một lần nữa.', 'gold');
        break;
      case 'gift':
        p.score += 1000; sfx.big();
        setMsg('<b>CHÚC MỪNG!</b> ' + nm + ' được tặng thẳng 1.000 điểm.', 'good');
        break;
      case 'zero':
        p.score = 0; sfx.bad();
        setMsg('<b>MẤT ĐIỂM.</b> Điểm của ' + nm + ' về 0.' + TL(), 'bad');
        renderPlayers(); return void setTimeout(passTurn, 1300);
      case 'danger':
        sfx.fail(); loseLives(p, 1);
        if (!p.alive) { renderAll(); return void setTimeout(() => afterDeath(p), 900); }
        setMsg('<b>CÚN GẶP NGUY!</b> Cún của ' + nm + ' mất một mạng, chỉ còn ' + p.lives + '.' + TL(), 'bad');
        renderAll(); return void setTimeout(passTurn, 1400);
      case 'bet':
        S.pending = 400; S.mult = 1; S.betting = false; sfx.click();
        setMsg('<b>CƯỢC ĐÔI!</b> ' + nm + ' chọn đi: nhận cược thì mỗi chữ đúng được <b>1.200 điểm</b> nhưng sai là cún mất <b>2 mạng</b>; bỏ qua thì ăn <b>400 điểm</b> mỗi chữ như thường.' +
          '<span class="minis"><button class="mini yes" type="button" data-bet="yes">NHẬN CƯỢC</button><button class="mini" type="button" data-bet="no">BỎ QUA</button></span>', 'gold');
        S.canSpin = false; renderAll(); return;
    }
    S.canSpin = true; renderAll();
  }

  /* ---------------- đoán chữ cái ---------------- */
  function guess(L) {
    if (S.pending == null || S.spinning) return;
    if (S.used.indexOf(L) >= 0) return;
    const p = S.players[S.cur];
    S.used.push(L);
    const set = letterSet();
    const pts = S.pending, mult = S.mult, wasBet = S.betting;
    S.pending = null; S.mult = 1; S.betting = false;

    if (set.has(L)) {
      S.revealed.push(L);
      let count = 0;
      for (const ch of S.answer) if (baseOf(ch) === L) count++;
      const gain = pts * count * mult;
      p.score += gain;
      sfx.good();
      setMsg('Chính xác! Có <b>' + count + '</b> chữ <b>' + L + '</b> — ' + p.name + ' được <b>' + fmt(gain) + ' điểm</b>.', 'good');
      renderBoard(L); renderAll();
      if (isSolved()) return void setTimeout(() => finishRound(p, 0, 'mở hết chữ cái'), 900);
      S.canSpin = true; updateControls();
    } else {
      const cost = wasBet ? 2 : 1;
      sfx.bad(); loseLives(p, cost);
      renderAll();
      if (!p.alive) {
        setMsg('Không có chữ <b>' + L + '</b> trong ô chữ...', 'bad');
        return void setTimeout(() => afterDeath(p), 1100);
      }
      setMsg('Không có chữ <b>' + L + '</b>. Cún của ' + p.name + ' mất ' + cost + ' mạng, còn ' + p.lives + '.' + TL(), 'bad');
      setTimeout(passTurn, 1500);
    }
  }

  function loseLives(p, n) {
    p.lives = Math.max(0, p.lives - n);
    if (p.lives === 0) p.alive = false;
    shakeScene();
  }

  function afterDeath(p) {
    sfx.fail();
    setMsg('<b>Chụp lưới rồi!</b> Cún của ' + p.name + ' đã bị bắt, ' + p.name + ' dừng cuộc chơi.', 'bad');
    renderAll();
    setTimeout(passTurn, 1200);
  }

  /* ---------------- đoán đáp án ---------------- */
  function openSolve() {
    if (S.spinning || !S.started) return;
    const hid = hiddenCount(), bonus = 300 + hid * 150;
    openModal(
      '<h3>Đoán đáp án</h3>' +
      '<div class="qq">' + esc(S.question) + '</div>' +
      '<p>Ô chữ có <b>' + S.answer.replace(/ /g, '').length + '</b> chữ cái, còn <b>' + hid + '</b> chữ đang ẩn.</p>' +
      '<input class="guessinput" id="solveInput" placeholder="Nhập đáp án..." autocomplete="off" spellcheck="false">' +
      '<div class="warn">Đúng thì được thưởng thêm <b>' + fmt(bonus) + ' điểm</b>. Sai thì cún bị bắt ngay và ' + esc(S.players[S.cur].name) + ' mất hẳn lượt chơi.</div>' +
      '<p style="font-size:12.5px;opacity:.75;margin-bottom:14px">Không cần gõ dấu — nhập không dấu vẫn được tính đúng.</p>' +
      '<div class="btns"><button class="ghost" data-act="close">Quay lại</button><button class="solve" data-act="confirm">CHỐT ĐÁP ÁN</button></div>'
    );
    const inp = $('solveInput');
    inp.focus();
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doSolve(inp.value); } });
  }

  function doSolve(text) {
    const p = S.players[S.cur];
    const hid = hiddenCount(), bonus = 300 + hid * 150;
    closeModal();
    if (loose(text) && loose(text) === loose(S.answer)) {
      p.score += bonus;
      S.revealed = [...letterSet()];
      renderBoard(); renderAll(); sfx.big();
      finishRound(p, bonus, 'đoán đúng đáp án');
    } else {
      p.lives = 0; p.alive = false;
      sfx.fail(); renderAll();
      setMsg('<b>Sai rồi!</b> Đáp án đúng là <b>' + esc(S.answer) + '</b>. Cún của ' + p.name + ' bị bắt.', 'bad');
      setTimeout(passTurn, 1500);
    }
  }

  /* ---------------- luân chuyển lượt ---------------- */
  function passTurn() {
    const alive = S.players.filter(p => p.alive);
    if (!alive.length) return void gameOver();
    let i = S.cur;
    for (let k = 0; k < S.players.length; k++) {
      i = (i + 1) % S.players.length;
      if (S.players[i].alive) break;
    }
    S.cur = i;
    S.pending = null; S.mult = 1; S.betting = false; S.canSpin = true;
    $('hubText').innerHTML = 'QUAY<br>ĐI!';
    renderAll();
    if (S.players.length > 1)
      setMsg('Đến lượt <b>' + S.players[S.cur].name + '</b>. Bấm QUAY NÓN hoặc đoán thẳng đáp án.', 'gold');
    else
      setMsg('Bấm <b>QUAY NÓN</b> để quay tiếp, hoặc đoán thẳng đáp án.', '');
  }

  function finishRound(winner, bonus, how) {
    S.solvedCount++;
    S.revealed = [...letterSet()]; renderBoard(); renderAll();
    const last = S.round >= S.maxRounds;
    const body =
      '<h3>' + esc(winner.name) + ' giải được ô chữ!</h3>' +
      '<div class="qq">' + esc(S.question) + '</div>' +
      '<div class="reveal">' + esc(S.answer) + '</div>' +
      '<p>' + esc(winner.name) + ' ' + how + (bonus ? ' và nhận thêm <b>' + fmt(bonus) + ' điểm thưởng</b>' : '') +
      '. Tổng điểm hiện tại: <b>' + fmt(winner.score) + '</b>.</p>' +
      '<p style="font-size:12.5px;opacity:.8">Kẻ bắt cún đành bỏ cuộc — cún con an toàn trong ván này.</p>' +
      '<div class="btns"><button class="cta" data-act="' + (last ? 'over' : 'next') + '">' + (last ? 'XEM KẾT QUẢ' : 'VÁN TIẾP THEO') + '</button></div>';
    openModal(body);
  }

  function nextRound() {
    closeModal();
    S.round++;
    S.players.forEach(p => { if (p.alive) p.lives = Math.min(MAX_LIVES, p.lives + 1); });
    nextPuzzle();
    S.canSpin = true;
    $('hubText').innerHTML = 'QUAY<br>ĐI!';
    renderAll(); renderBoard();
    setMsg('<b>Ván ' + S.round + '</b> bắt đầu. Lượt của <b>' + S.players[S.cur].name + '</b>.', 'gold');
  }

  function gameOver() {
    const rank = S.players.slice().sort((a, b) => b.score - a.score);
    let html = '<h3>' + (S.mode === 'solo' ? 'Cún bị bắt mất rồi!' : 'Kết quả chung cuộc') + '</h3>';
    if (S.mode === 'solo') {
      html += '<p>Bạn đã giải được <b>' + S.solvedCount + '</b> ô chữ và ghi được <b>' + fmt(S.players[0].score) + '</b> điểm trước khi cún bị chụp lưới.</p>';
      html += '<div class="qq">' + esc(S.question) + '</div>';
      html += '<div class="reveal">' + esc(S.answer) + '</div>';
      html += '<p style="font-size:13px">Đó là đáp án của ô chữ cuối cùng.</p>';
    } else {
      html += '<div class="rank">' + rank.map((p, i) =>
        '<div class="' + (i === 0 ? 'first' : '') + '"><span class="pos">' + (i + 1) + '</span><span>' + esc(p.name) +
        (p.alive ? '' : ' <small style="opacity:.6">(cún bị bắt)</small>') + '</span><span class="pts">' + fmt(p.score) + '</span></div>'
      ).join('') + '</div>';
      html += '<p><b>' + esc(rank[0].name) + '</b> giành chiến thắng chung cuộc!</p>';
    }
    html += '<div class="btns"><button class="cta" data-act="restart">CHƠI LẠI</button></div>';
    openModal(html);
    sfx.big();
  }

  /* ---------------- hiển thị ---------------- */
  const multi = () => S.players.length > 1;
  const TL = () => multi() ? ' Mất lượt.' : '';

  function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function setMsg(html, kind) { const m = $('msg'); m.innerHTML = html; m.className = 'msgline' + (kind ? ' ' + kind : ''); }

  function renderBoard(justLetter) {
    const board = $('board'); board.innerHTML = '';
    S.answer.split(' ').forEach(word => {
      const w = el('div', 'word');
      for (const ch of word) {
        const b = baseOf(ch);
        const t = el('div', 'tile');
        if (!b) { t.textContent = ch; }
        else if (S.revealed.indexOf(b) >= 0) { t.textContent = ch; if (justLetter && b === justLetter) t.classList.add('just'); }
        else { t.classList.add('blank'); t.textContent = '•'; }
        w.appendChild(t);
      }
      board.appendChild(w);
    });
    fitBoard();
    renderQuestion();
    $('chipRound').textContent = S.mode === 'solo' ? 'Ô chữ số ' + S.round : 'Ván ' + S.round + '/' + S.maxRounds;
    $('chipLen').textContent = S.answer.replace(/ /g, '').length + ' chữ cái';
  }

  function fitBoard() {
    const board = $('board');
    const avail = Math.max(180, board.clientWidth - 30);
    const words = S.answer.split(' ');
    const longest = Math.max(1, ...words.map(w => w.length));
    const total = S.answer.replace(/ /g, '').length;
    let t = Math.floor((avail - 5 * (longest - 1)) / longest);
    const rows = Math.ceil(total / Math.max(1, Math.floor(avail / (t + 5))));
    const perRow = Math.max(1, Math.floor(avail / 30));
    if (total > perRow * 4) t = Math.min(t, 26);
    t = Math.max(15, Math.min(rows <= 1 ? 52 : 42, t));
    board.style.setProperty('--t', t + 'px');
  }
  let rzT = null;
  window.addEventListener('resize', () => { clearTimeout(rzT); rzT = setTimeout(() => { if (S.started) fitBoard(); }, 150); });

  function renderQuestion() {
    $('qtext').textContent = S.question;
  }

  function renderPlayers() {
    const box = $('players'); box.innerHTML = '';
    box.classList.toggle('solo', S.players.length === 1);
    S.players.forEach((p, i) => {
      const c = el('div', 'pcard' + (i === S.cur ? ' active' : '') + (p.alive ? '' : ' out'));
      const n = el('div', 'pname'); n.textContent = (i === S.cur ? '▶ ' : '') + p.name;
      const s = el('div', 'pscore'); s.innerHTML = fmt(p.score) + '<small>ĐIỂM</small>';
      const lv = el('div', 'plives');
      for (let k = 0; k < Math.max(START_LIVES, p.lives); k++) { const d = el('i'); if (k < p.lives) d.className = 'on'; lv.appendChild(d); }
      c.append(n, s, lv);
      box.appendChild(c);
    });
  }

  const SCENE = [
    ['Cún đang an toàn',     'Kẻ bắt cún còn ở tít đằng xa. Mỗi lần đoán sai một chữ cái là hắn tiến lại gần thêm một bước.'],
    ['Hắn đã tới đầu ngõ',   'Cún vẫn bình tĩnh, nhưng bóng tấm lưới đã hiện ra sau hàng rào.'],
    ['Cún bắt đầu chột dạ',  'Trời tối dần và tiếng bước chân mỗi lúc một gần. Hãy chọn chữ cái thật chắc tay.'],
    ['Tấm lưới đã kề bên',   'Cún run lẩy bẩy rồi. Chỉ sai thêm hai lần nữa là hắn chụp được.'],
    ['Chỉ còn một bước nữa', 'Lưới đã giơ lên ngay trên đầu cún. Sai một chữ cái nữa thôi là hết.'],
    ['Cún bị chụp lưới rồi', 'Kẻ bắt cún đã tóm được. Ván này coi như thua — chơi lại để cứu cún nào.']
  ];

  function renderScene() {
    const p = S.players[S.cur]; if (!p) return;
    const danger = Math.max(0, Math.min(5, START_LIVES - p.lives));
    $('scene').dataset.danger = String(danger);

    const box = $('bigLives'); box.innerHTML = '';
    for (let k = 0; k < p.lives; k++) {
      const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      const u = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      u.setAttribute('href', '#ic-bone'); s.appendChild(u);
      box.appendChild(s);
    }
    const t = SCENE[danger];
    $('sceneHead').textContent = multi() ? t[0] + ' — cún của ' + p.name : t[0];
    $('sceneTxt').textContent = p.lives > 0 ? 'Còn ' + p.lives + ' mạng. ' + t[1] : t[1];
    $('sceneBar').classList.toggle('warn', danger >= 3);
  }

  function shakeScene() {
    const sc = $('scene');
    sc.classList.remove('hit');
    void sc.offsetWidth;
    sc.classList.add('hit');
    setTimeout(() => sc.classList.remove('hit'), 520);
  }

  function renderKeys() {
    const box = $('keys');
    if (!box.childElementCount) {
      ALPHABET.forEach(L => {
        const b = el('button', 'key', L);
        b.dataset.letter = L; b.type = 'button';
        b.addEventListener('click', () => { audioInit(); guess(L); });
        box.appendChild(b);
      });
    }
    const set = letterSet(), open = S.pending != null && !S.spinning;
    [...box.children].forEach(b => {
      const L = b.dataset.letter;
      const used = S.used.indexOf(L) >= 0;
      b.className = 'key' + (used ? (set.has(L) ? ' hit' : ' miss') : (open ? '' : ' locked'));
      b.disabled = used || !open;
    });
  }

  function updateControls() {
    $('btnSpin').disabled = !S.canSpin || S.spinning || !S.started;
    $('btnSolve').disabled = S.spinning || !S.started;
    $('btnSpin').textContent = S.spinning ? 'ĐANG QUAY...' : (S.pending != null ? 'CHỌN CHỮ CÁI' : 'QUAY NÓN');
    renderKeys();
  }

  function renderAll() { renderPlayers(); renderScene(); updateControls(); }

  /* ---------------- modal ---------------- */
  function openModal(html) { $('sheet').innerHTML = html; $('modal').hidden = false; }
  function closeModal() { $('modal').hidden = true; $('sheet').innerHTML = ''; }

  $('msg').addEventListener('click', e => {
    const b = e.target.closest('[data-bet]');
    if (!b || S.pending == null) return;
    audioInit(); sfx.click();
    if (b.dataset.bet === 'yes') {
      S.mult = 3; S.betting = true;
      setMsg('<b>Đã nhận cược!</b> Mỗi chữ cái đúng được <b>1.200 điểm</b>, nhưng đoán sai là cún mất <b>2 mạng</b>. Chọn chữ cái đi!', 'gold');
    } else {
      S.mult = 1; S.betting = false;
      setMsg('Bỏ qua cược. Mỗi chữ cái đúng được <b>400 điểm</b> — chọn chữ cái nào!', 'gold');
    }
  });

  $('modal').addEventListener('click', e => {
    const act = e.target.closest('[data-act]');
    if (!act) { if (e.target.id === 'modal') { /* giữ modal */ } return; }
    audioInit();
    const a = act.dataset.act;
    if (a === 'close') closeModal();
    else if (a === 'confirm') doSolve(($('solveInput') || {}).value || '');
    else if (a === 'next') nextRound();
    else if (a === 'over') { closeModal(); gameOver(); }
    else if (a === 'restart') { closeModal(); toStart(); }
  });

  const RULES =
    '<h3>Luật chơi</h3>' +
    '<ul>' +
    '<li>Mỗi ván có một <b>câu hỏi hiện sẵn</b> phía trên ô chữ. Đáp án của câu hỏi chính là ô chữ phải mở.</li>' +
    '<li>Quay nón rồi chọn một chữ cái. Mỗi chữ cái xuất hiện trong ô chữ được cộng đúng số điểm vừa quay.</li>' +
    '<li>Bảng chữ cái phân biệt rõ <b>A — Ă — Â</b>, <b>E — Ê</b>, <b>O — Ô — Ơ</b>, <b>U — Ư</b> và <b>D — Đ</b>. Chọn đúng nguyên âm sẽ mở mọi dấu thanh của nguyên âm đó.</li>' +
    '<li>Đoán sai chữ cái: kẻ bắt cún tiến thêm một bước và bạn mất lượt. Hết 5 mạng là cún bị chụp lưới.</li>' +
    '<li><b>ĐOÁN ĐÁP ÁN</b> dùng được bất cứ lúc nào. Càng nhiều chữ còn ẩn thì thưởng càng lớn, nhưng sai là cún bị bắt ngay.</li>' +
    '</ul>' +
    '<h3 style="font-size:19px;margin-top:4px">Các ô trên vòng quay</h3>' +
    '<ul>' +
    '<li><b>Điểm</b> — từ 200 đến 1.000 cho mỗi chữ cái đoán đúng.</li>' +
    '<li><b>MẤT LƯỢT</b> — nhường nón cho người kế tiếp.</li>' +
    '<li><b>GẤP ĐÔI</b> / <b>CHIA ĐÔI</b> — điểm hiện có nhân đôi hoặc chia đôi.</li>' +
    '<li><b>THÊM MẠNG</b> và <b>CỨU TRỢ</b> — đẩy kẻ bắt cún lùi lại một bước.</li>' +
    '<li><b>MAY MẮN</b> — mở miễn phí một chữ cái ngẫu nhiên.</li>' +
    '<li><b>CHÚC MỪNG</b> — tặng thẳng 1.000 điểm.</li>' +
    '<li><b>ĐỔI CÂU</b> — bỏ câu hiện tại, nhận một câu hỏi mới rồi quay tiếp.</li>' +
    '<li><b>QUAY LẠI</b> — được quay thêm một lần.</li>' +
    '<li><b>MẤT ĐIỂM</b> — điểm về 0 và mất lượt.</li>' +
    '<li><b>CÚN GẶP NGUY</b> — mất ngay một mạng và mất lượt.</li>' +
    '<li><b>CƯỢC ĐÔI</b> — bạn tự chọn: nhận cược thì đúng được gấp ba điểm, sai mất hai mạng; bỏ qua thì ăn điểm như thường.</li>' +
    '</ul>' +
    '<div class="btns"><button class="cta" data-act="close">ĐÃ HIỂU</button></div>';

  /* ---------------- màn hình bắt đầu ---------------- */
  function buildNameFields() {
    const n = S.mode === 'solo' ? 1 : parseInt($('numPlayers').value, 10);
    const box = $('nameFields');
    const old = [...box.querySelectorAll('input')].map(i => i.value);
    box.innerHTML = '';
    for (let i = 0; i < n; i++) {
      const f = el('div', 'field');
      const lab = el('label', null, n === 1 ? 'Tên của bạn' : 'Người chơi ' + (i + 1));
      lab.setAttribute('for', 'pn' + i);
      const inp = el('input');
      inp.id = 'pn' + i; inp.maxLength = 14; inp.autocomplete = 'off';
      inp.placeholder = n === 1 ? 'Bạn' : 'Người chơi ' + (i + 1);
      inp.value = old[i] || '';
      f.append(lab, inp); box.appendChild(f);
    }
  }

  function setMode(m) {
    S.mode = m;
    $('modeSolo').setAttribute('aria-pressed', m === 'solo');
    $('modeParty').setAttribute('aria-pressed', m === 'party');
    $('partyOpts').hidden = m !== 'party';
    buildNameFields();
  }

  function startGame() {
    audioInit();
    const inputs = [...$('nameFields').querySelectorAll('input')];
    S.players = inputs.map((inp, i) => ({
      name: (inp.value || '').trim().slice(0, 14) || (inputs.length === 1 ? 'Bạn' : 'Người chơi ' + (i + 1)),
      score: 0, lives: START_LIVES, alive: true
    }));
    S.maxRounds = S.mode === 'solo' ? Infinity : parseInt($('numRounds').value, 10);
    S.cur = 0; S.round = 1; S.solvedCount = 0; S.pool = freshPool();
    S.started = true; S.canSpin = true;
    nextPuzzle();
    $('screenStart').hidden = true;
    $('screenGame').hidden = false;
    $('footNote').hidden = false;
    $('hubText').innerHTML = 'QUAY<br>ĐI!';
    renderBoard(); renderAll();
    setMsg(S.players.length > 1
      ? 'Đọc câu hỏi phía trên đi. Lượt đầu tiên thuộc về <b>' + S.players[0].name + '</b>.'
      : 'Đọc câu hỏi phía trên, rồi bấm <b>QUAY NÓN</b> để bắt đầu giải cứu cún con.', 'gold');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function toStart() {
    S.started = false;
    $('screenGame').hidden = true;
    $('footNote').hidden = true;
    $('screenStart').hidden = false;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ---------------- gắn sự kiện ---------------- */
  $('modeSolo').addEventListener('click', () => { audioInit(); setMode('solo'); });
  $('modeParty').addEventListener('click', () => { audioInit(); setMode('party'); });
  $('numPlayers').addEventListener('change', buildNameFields);
  $('btnStart').addEventListener('click', startGame);
  $('btnSpin').addEventListener('click', spin);
  $('btnSolve').addEventListener('click', () => { audioInit(); openSolve(); });
  $('btnRules').addEventListener('click', () => { audioInit(); openModal(RULES); });
  $('btnMusic').addEventListener('click', () => setMusic(!A.on));

  document.addEventListener('keydown', e => {
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    if (!S.started || !$('modal').hidden) return;
    if (e.key === 'Enter' || e.key === ' ') {
      if (!$('btnSpin').disabled) { e.preventDefault(); spin(); }
      return;
    }
    const ch = (e.key || '').toUpperCase();
    if (ch.length !== 1) return;
    const b = baseOf(ch);
    if (b && S.pending != null && S.used.indexOf(b) < 0) { e.preventDefault(); guess(b); }
  });

  /* ---------------- khởi động ---------------- */
  function boot(data) {
    setMode('solo');
    buildNameFields();
    drawWheel(-Math.PI / 2);
    startBlink();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => drawWheel(S.angle));
    try {
      if (data && data.v === 1 && data.S) {
        Object.assign(S, data.S);
        if (S.started) {
          $('screenStart').hidden = true; $('screenGame').hidden = false; $('footNote').hidden = false;
          S.spinning = false; renderBoard(); renderAll();
          setMsg('Ván chơi được khôi phục. Bấm <b>QUAY NÓN</b> để tiếp tục.', 'gold');
        }
      }
    } catch (err) { /* bắt đầu ván mới */ }
  }
  boot({});
})();
